package com.agency04.devcademy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootProjectTemplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
